#include <iostream>

using namespace std;

int majorityElement(int arr[], int n)
{
    int m, cnt = 0;

    /*
        1, 8, 7, 3, 3, 3, 3
    */
    for(int i = 0; i < n; i++) // i = 0 , 1, 2, 3, 4, 5, 6, 7
    {
        if(cnt == 0)
        {
            m = arr[i]; // m = 1, 7, 3
            cnt = cnt + 1; // cnt = 1
        }
        else
        {
            if(m == arr[i])
            {
                cnt++; // i = 2, 3
            }
            else
            {
                cnt--; // cnt = 0
            }
        }
    }

    cnt = 0;

    for(int i = 0; i < n; i++)
    {
        if(m == arr[i])
        {
            cnt++;
        }
        if(cnt > (n / 2))
        {
            return m;
        }
    }

    return -1;
}

int main()
{
    int arr[] = {2, 1, 2, 2, 3, 2, 4};
    int majority;

    majority = majorityElement(arr, 7);

    cout<<"Majority element is:"<<majority<<endl;

    return 0;
}
