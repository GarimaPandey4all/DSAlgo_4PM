#include <iostream>

using namespace std;

int findSplitIndex(int arr[], int n)
{
    int leftSum, rightSum, sum = 0;

    for(int i = 0; i < n; i++)
    {
        sum += arr[i];
    }

    leftSum = sum;
    rightSum = 0;

    for(int i = n - 1; i >= 0; i--)
    {
        rightSum += arr[i];
        leftSum -= arr[i];

        if(leftSum == rightSum)
        {
            return i;
        }
    }

    return -1;

}

int main()
{
    int arr[] = {1, 2, 3, 4, 5, 5};
    int splitIndex;

    splitIndex = findSplitIndex(arr, 6);

    cout<<"Split Array Position is:"<<splitIndex;

    return 0;
}
