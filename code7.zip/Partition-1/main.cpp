#include <iostream>

using namespace std;

int findSplitIndex(int arr[], int n)
{
    int leftSum = 0, rightSum;

    for(int i = 0; i < n; i++)
    {
        leftSum += arr[i];

        rightSum = 0;

        for(int j = i + 1; j < n; j++)
        {
            rightSum += arr[j];
        }

        if(leftSum == rightSum)
        {
            return i;
        }
    }

    return -1;

}

int main()
{
    int arr[] = {1, 2, 3, 4, 5, 5};
    int splitIndex;

    splitIndex = findSplitIndex(arr, 6);

    cout<<"Split Array Position is:"<<splitIndex;

    return 0;
}
