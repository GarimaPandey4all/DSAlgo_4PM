#include <iostream>

using namespace std;

void DNF(int arr[], int n)
{
    int c, l, h;

    c = l = 0;
    h = n - 1;

    while(c < h)
    {
        if(arr[c] == 0)
        {
            swap(arr[c], arr[l]);
            l++;
            c++;
        }
        if(arr[c] == 1)
        {
            c++;
        }
        if(arr[c] == 2)
        {
            swap(arr[c], arr[h]);
            h--;
        }
    }
}

int main()
{
    int arr[] = {0, 1, 0, 1, 2, 1, 2, 1};

    DNF(arr, 8);

    cout<<"Sorted Array is:\n";
    for(int i = 0; i < 8; i++)
    {
        cout<<arr[i]<<"  ";
    }

    return 0;
}
