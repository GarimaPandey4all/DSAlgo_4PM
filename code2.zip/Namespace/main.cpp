#include <iostream>

using namespace std;

namespace value {
    int val = 100;
}

int main()
{

    int val = 500;

    cout << val << endl;

    cout<<value::val<<endl;

    return 0;
}
