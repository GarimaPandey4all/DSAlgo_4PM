#include <iostream>

using namespace std;

int main()
{
    int arr[10], i, j, temp;

     cout<<"Enter any value in lists:";
     for(i = 0; i < 10; i++)
     cin>>arr[i];

     for(i = 0; i < 10 - 1; i++)
     {
         for(j = 0; j < 10 - 1 - i; j++)
         {
             if(arr[j] > arr[j + 1])
             {
                 temp = arr[j];
                 arr[j] = arr[j + 1];
                 arr[j + 1] = temp;
             }
         }
     }

     cout<<"Bubble Sorted Array is:\n";
     for(i = 0; i < 10; i++)
     {
         cout<<arr[i]<<"  ";
     }

    return 0;
}
