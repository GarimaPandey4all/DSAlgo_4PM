#include <iostream>

using namespace std;

int main()
{
    int arr[10], n, i, j, minimum, temp;

    cout<<"Enter number of elements:";
    cin>>n;

    cout<<"Enter value in an array:";
    for(i = 0; i < n; i++)
    {
        cin>>arr[i];
    }

    for(i = 0; i < n - 1; i++)
    {
        minimum = i;
        for(j = i + 1; j < n; j++)
        {
            if(arr[j] < arr[minimum])
            {
                minimum = j;
            }
        }

        temp = arr[i];
        arr[i] = arr[minimum];
        arr[minimum] = temp;
    }

    cout<<"Sorted Array:";
    for(i = 0; i < n; i++)
    {
        cout<<arr[i]<<"  ";
    }

    return 0;
}
