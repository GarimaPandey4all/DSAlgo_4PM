#include <iostream>

using namespace std;

struct node {

    int info;
    struct node *link;
};

struct node *last = NULL;

struct node *createNode()
{
    struct node *n;

    n = (struct node *)malloc(sizeof(struct node));

    return (n);
};

void insertAtEmpty()
{
    struct node *temp;

    if(last == NULL)
    {
        temp = createNode();

        cout<<"Enter any number:";
        cin>>temp->info;

        last = temp;
        last->link = last;
    }
    else
    {
        cout<<"List is not empty"<<endl;
    }
}

void insertAtStart()
{
    struct node *temp;

    if(last == NULL)
    {
        cout<<"List is Empty";
    }
    else
    {
        temp = createNode();

        cout<<"Enter any number:";
        cin>>temp->info;

        temp->link = last->link;
        last->link = temp;
    }
}

void insertAtEnd()
{
    struct node *temp;

    if(last == NULL)
    {
        cout<<"List is Empty";
    }
    else
    {
        temp = createNode();

        cout<<"Enter any number:";
        cin>>temp->info;

        temp->link = last->link;

        last->link = temp;

        last = temp;
    }
}

int insertAfterNode()
{
    struct node *temp, *ptr;
    int Search;

    if(last == NULL)
    {
        cout<<"List is Empty";
        return 0;
    }

    cout<<"Enter any number to be search:";
    cin>>Search;

    ptr = last->link; // first node

    do
    {
        if(ptr->info == Search)
        {
            temp = createNode();

            cout<<"Enter any number:";
            cin>>temp->info;

            temp->link = ptr->link;
            ptr->link = temp;

            if(ptr == last)
            {
                last = temp;
            }

            return 1;
        }

        ptr = ptr->link;

    }while(ptr != last->link);

    cout<<"Search value is not found";
    return 0;
}

void viewList()
{
    struct node *t;

    if(last == NULL)
    {
        cout<<"List is Empty";
    }
    else
    {
        t = last->link;

        do
        {
            cout<<t->info<<"  ";
            t = t->link;
        }while(t != last->link);
    }
}


int main()
{
    int choice;

    while(1)
    {
        cout<<"\n\n1. Insert at Empty\n";
        cout<<"2. Insert at Start\n";
        cout<<"3. Insert at end\n";
        cout<<"4. Insert after node\n";
        cout<<"5. View list\n";
        cout<<"6. Exit\n";
        cout<<"\nEnter your choice:\n";
        cin>>choice;

        switch(choice)
        {
        case 1:
            insertAtEmpty();
            break;

        case 2:
            insertAtStart();
            break;

        case 3:
            insertAtEnd();
            break;

        case 4:
            insertAfterNode();
            break;

        case 5:
            viewList();
            break;

        case 6:
            exit(0);

        default:
            cout<<"Invalid Choice";
        }
    }

    return 0;
}
