#include <iostream>

using namespace std;

void quickSort(int arr[], int first, int last)
{
    int pivot, i, j, temp;

    if(first < last)
    {
        pivot = first;
        i = first;
        j = last;

        while(i < j)
        {
            while(arr[pivot] >= arr[i] && i < last)
            {
                i++;
            }

            while(arr[pivot] < arr[j])
            {
                j--;
            }

            if(i < j)
            {
                temp = arr[i];
                arr[i] = arr[j];
                arr[j] = temp;
            }
        }

        //swapping the pivot value
        temp = arr[pivot];
        arr[pivot] = arr[j];
        arr[j] = temp;

        //left- subarray
        quickSort(arr, 0, j - 1);

        //right- subarray
        quickSort(arr, j + 1, last);
    }
}

int main()
{
    int arr[10], n, i;

    cout<<"Enter number of elements:";
    cin>>n;

    cout<<"Enter value in an array:";
    for(i = 0; i < n; i++)
    {
        cin>>arr[i];
    }

    quickSort(arr, 0, n - 1); //function calling

    cout<<"Sorted Array is:\n";
    for(i = 0; i < n; i++)
    {
        cout<<arr[i]<<"  ";
    }

    return 0;
}
