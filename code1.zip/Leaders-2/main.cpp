#include <iostream>

using namespace std;

void leadersArray(int arr[], int n)
{
    int maxElement = 0;

    for(int i = n - 1; i >= 0; i--)
    {
        if(arr[i] > maxElement)
        {
            cout<<"This is Leader:"<<arr[i]<<endl;
            maxElement = arr[i];
        }
    }
}

int main()
{
    int arr[] = {10, 12, 5, 6, 1};

    leadersArray(arr, 5);

    return 0;
}
