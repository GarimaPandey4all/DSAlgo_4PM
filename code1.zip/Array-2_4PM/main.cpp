#include <iostream>
//#define MONTHS 12

using namespace std;

int main()
{
    int days[MONTHS] = {31, 28, 30, 31, 30, 31, 30, 31, 30, 31, 30, 31};
    const int MONTHS = 12;

    for(int i = 0; i < MONTHS; i++)
    {
        cout<<i+1<<" month has "<<days[i]<<endl;
    }

    return 0;
}
