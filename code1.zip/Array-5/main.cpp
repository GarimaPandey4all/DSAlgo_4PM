#include <iostream>

using namespace std;

int main()
{
    int matrix1[5][5], i, j, rows, columns, totalCount = 0;

    cout<<"Enter number of rows and columns:";
    cin>>rows>>columns;

    cout<<"Enter value in matrix-1:\n";
    for(i = 0; i < rows; i++)
    {
        for(j = 0; j < columns; j++)
        {
            cin>>matrix1[i][j];
        }
    }

    cout<<"Values in matrix-1 are:\n";
    for(i = 0; i < rows; i++)
    {
        for(j = 0; j < columns; j++)
        {
            cout<<matrix1[i][j]<<"\t";
        }
        cout<<endl;
    }

    for(i = 0; i < rows; i++)
    {
        for(j = 0; j < columns; j++)
        {
            if(matrix1[i][j] == 0)
            {
                totalCount++;
            }
        }
    }

    if(totalCount > (rows * columns)/2)
    {
        cout<<"Sparse Matrix"<<endl;
    }
    else
    {
        cout<<"Not Sparse Matrix"<<endl;
    }

    return 0;
}
