#include <iostream>

using namespace std;

int findSingleNumber(int arr[], int n)
{
    int i, j, countNumber = 0;

    for(i = 0; i < n; i++)
    {
        for(j = 0; j < n; j++)
        {
            if(arr[i] == arr[j])
            {
                countNumber++;
            }
        }

        if((countNumber) % 2 != 0)
        {
            return arr[i];
        }
    }
    return 0; //failure
}

int main()
{
    int arr[] = {2, 4, 2, 4, 1, 1, 1};

    int singleNumber = findSingleNumber(arr, 7);

    cout<<"Single Number is:"<<singleNumber<<endl;

    return 0;
}

