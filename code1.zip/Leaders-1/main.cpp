#include <iostream>

using namespace std;

void leadersArray(int arr[], int n)
{
    int j;

    for(int i = 0; i < n; i++)
    {
        for(j = i + 1; j < n; j++)
        {
            if(arr[i] <= arr[j])
            {
                break;
            }
        }
        if(j == n)
            cout<<"This is Leader:"<<arr[i]<<"  ";
    }
}


int main()
{
    int arr[] = {10, 12, 5, 6, 1};

    leadersArray(arr, 5);

    return 0;
}
