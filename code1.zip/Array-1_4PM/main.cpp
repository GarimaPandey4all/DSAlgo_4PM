#include <iostream>

using namespace std;

int main()
{
    int arr[5] = {10}; // array declaration

    //Traditional way of initalization
    int arr2[5] = {10, 20, 30, 40, 50};

    //Compile time initialization
    int arr3[] = {10, 20, 30};

    cout<<arr2[4]<<endl;

    cout<<arr3[0]<<endl;

    cout<<arr[2]<<endl;

    for(int i = 0; i < 5; i++)
    {
        cout<<arr2[i]<<"  ";
    }

    return 0;
}
