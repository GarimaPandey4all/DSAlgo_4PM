#include <iostream>

using namespace std;

int main()
{
    int arr[10], temp[10], i, j, k, n, Size, l1, h1, l2, h2;

    cout<<"Enter number of elements:";
    cin>>n;

    cout<<"Enter values:\n";
    for(i = 0; i < n; i++)
    {
        cin>>arr[i];
    }

    /*

        3, 6, 2, 5, 1

    size=1:  3, 6, 2, 5, 1

    size=2:  2, 3, 5, 6, 1

    size-4:  1, 2, 3, 5, 6


    */

    for(Size = 1; Size < n; Size = Size * 2) // size = 1, 2, 4
    {
        l1 = 0; // 0
        k = 0; // index for temp array

        while(l1 + Size < n) // 1 < 5, 3 < 5, 5 < 5, 2 < 5
        {
            h1 = l1 + Size - 1; // 0, 2, 1, 3
            l2 = h1 + 1; // 1, 3, 2, 4
            h2 = l2 + Size - 1; // 1, 3, 3, 7

            //h2 exceeds
            if(h2 >= n)
            {
                h2 = n - 1; // 4
            }

            //Merge two pairs

            i = l1; // 0, 2, 0, 0
            j = l2; // 1, 3, 2, 4


            /*
                Orig Array
                 2, 3, 5, 6, 1

                Temp Array
                1, 2, 3, 5, 6

            */
            while(i <= h1 && j <= h2)
            {
                if(arr[i] <= arr[j]) // 3 < 6, 2 < 5, 2 < 1
                    temp[k++] = arr[i++]; // i = 1, k = 2
                else
                    temp[k++] = arr[j++]; // k = 1, j = 5
            }

            while(i <= h1)
            {
                temp[k++] = arr[i++];// i = 1, 2, 3, k = 2, 3, 4
            }

            while(j <= h2)
            {
                temp[k++] = arr[j++]; // j = 4, k = 4
            }

            l1 = h2 + 1; // 1 + 1 = 2, 4, 4

        }


        //any pair left
        for(i = l1; i < n; i++)
        {
            temp[k++] = arr[i];
        }

        for(i = 0; i < n ; i++)
        {
            arr[i] = temp[i];
        }

        cout<<"\nSize of"<<Size<<", Elements are:";
        for(i = 0;i < n; i++)
        {
            cout<<arr[i]<<"  ";
        }
    }

    cout<<"\nSorted Array:";
    for(i = 0; i < n; i++)
    {
        cout<<arr[i]<<"  ";
    }

    return 0;
}
