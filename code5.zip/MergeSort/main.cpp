#include <iostream>

using namespace std;

int main()
{
    int arr[10], temp[10], i, j, k, n, Size, l1, h1, l2, h2;

    cout<<"Enter number of elements:";
    cin>>n;

    cout<<"Enter values:\n";
    for(i = 0; i < n; i++)
    {
        cin>>arr[i];
    }

    /*

        3, 6, 2, 5, 1, 8, 7, 4


    */

    for(Size = 1; Size < n; Size = Size * 2) // size = 1
    {
        l1 = 0; // 0
        k = 0; // index for temp array

        while(l1 + Size < n) // 1 < 8, 3 < 8
        {
            h1 = l1 + Size - 1; // 0
            l2 = h1 + 1; // 1
            h2 = l2 + Size - 1; // 1

            //h2 exceeds
            if(h2 >= n)
            {
                h2 = n - 1;
            }

            //Merge two pairs

            i = l1; // 0
            j = l2; // 1


            /*
                Temp Array

                3, 6
            */
            while(i <= h1 && j <= h2)
            {
                if(arr[i] <= arr[j]) // 3 < 6
                    temp[k++] = arr[i++]; // i = 1, k = 1
                else
                    temp[k++] = arr[j++];
            }

            while(i <= h1)
            {
                temp[k++] = arr[i++];
            }

            while(j <= h2)
            {
                temp[k++] = arr[j++]; // j = 1, k = 2
            }

            l1 = h2 + 1; // 1 + 1 = 2

        }


        //any pair left
        for(i = l1; i < n; i++)
        {
            temp[k++] = arr[i];
        }

        for(i = 0; i < n ; i++)
        {
            arr[i] = temp[i];
        }

        cout<<"\nSize of"<<Size<<", Elements are:";
        for(i = 0;i < n; i++)
        {
            cout<<arr[i]<<"  ";
        }
    }

    cout<<"\nSorted Array:";
    for(i = 0; i < n; i++)
    {
        cout<<arr[i]<<"  ";
    }

    return 0;
}
