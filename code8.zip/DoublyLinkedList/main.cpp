#include <iostream>

using namespace std;

struct node {
    struct node *prev;
    int info;
    struct node *next;
};

struct node *START = NULL;

struct node *createNode()
{
    struct node *n;

    n = (struct node *)malloc(sizeof(struct node));

    return n;
};

void insertAtStart()
{
    struct node *temp;

    if(START == NULL)
    {
        temp = createNode();

        temp->prev = NULL;

        cout<<"Enter your number:";
        cin>>temp->info;

        temp->next = START;

        START = temp;
    }
    else
    {
        cout<<"List has some nodes";
    }
}

void insertATLast()
{
    struct node *temp, *t;

    temp = createNode();

    cout<<"Enter any number:";
    cin>>temp->info;

    temp->next = NULL;

    if(START == NULL)
    {
        temp->prev = NULL;
        START = temp;
    }
    else
    {
        t = START;

        while(t->next != NULL)
        {
            t = t->next;
        }

        temp->prev = t;
        t->next = temp;
    }
}

struct node *searchNode()
{
    struct node *temp;
    int Search;

    if(START == NULL)
    {
        return NULL;
    }
    else
    {
        cout<<"Enter any number to be search:";
        cin>>Search;

        temp = START;

        while(temp != NULL)
        {
            if(temp->info == Search)
            {
                return (temp);
            }
            temp = temp->next;
        }

        return NULL;
    }
};

void insertAfterNode()
{
    struct node *temp, *ptr;

    ptr = searchNode();

    if(ptr == NULL)
    {
        cout<<"Invalid Search. List is Empty";
    }
    else
    {
        temp = createNode();

        cout<<"Enter any number:";
        cin>>temp->info;

        temp->prev = ptr;
        temp->next = ptr->next;

        if(ptr->next != NULL)
            ptr->next->prev = temp;

        ptr->next = temp;
    }
}

void viewList()
{
    struct node *t;

    if(START == NULL)
    {
        cout<<"List is Empty";
    }
    else
    {
        t = START;

        while(t != NULL)
        {
            cout<<t->info<<"  ";
            t = t->next;
        }
    }
}

int main()
{
    int choice;

    while(1)
    {
        cout<<endl<<endl<<"1. Insert at Start"<<endl;
        cout<<"2. Insert at last"<<endl;
        cout<<"3. Insert after node"<<endl;
        cout<<"4. View list"<<endl;
        cout<<"5. Exit"<<endl;

        cout<<endl<<"Enter your choice:";
        cin>>choice;

        switch(choice)
        {
        case 1:
            insertAtStart();
            break;

        case 2:
            insertATLast();
            break;

        case 3:
            insertAfterNode();
            break;

        case 4:
            viewList();
            break;

        case 5:
            exit(0);

        default:
            cout<<"Invalid Choice";
        }
    }

    return 0;
}
