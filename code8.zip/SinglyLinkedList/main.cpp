#include <iostream>

using namespace std;

struct node {
    int info;
    struct node *link;
};

struct node *START = NULL;

struct node *createNode() //function
{
    struct node *n;

    n = (struct node *)malloc(sizeof(struct node)); // malloc() always return void pointer so we need to type cast it.

    return (n);

};

void insertNode()
{
    struct node *temp, *t;

    temp = createNode();

    cout<<"Enter any number:";
    cin>>temp->info;

    temp->link = NULL; //last node

    if(START == NULL) // link list empty
    {
        START = temp;
    }
    else
    {
        t = START;

        while(t->link != NULL)
        {
            t = t->link;
        }

        t->link = temp;
    }
}

void deleteNode()
{
    struct node *t;

    if(START == NULL)
    {
        cout<<"List is empty";
    }
    else
    {
        t = START;

        START = START->link;

        free(t);
    }
}

void viewList()
{
    struct node *t;

    if(START == NULL)
    {
        cout<<"List is empty";
    }
    else
    {
        t = START;

        while(t != NULL)
        {
            cout<<t->info<<"  ";
            t = t->link;
        }
    }
}

int main()
{
    int choice;

    while(1)
    {
        cout<<endl<<endl<<"1. Insert"<<endl;
        cout<<"2. Delete"<<endl;
        cout<<"3. Display"<<endl;
        cout<<"4. Exit"<<endl;

        cout<<endl<<"Enter your choice:";
        cin>>choice;

        switch(choice)
        {
        case 1:
            insertNode();
            break;

        case 2:
            deleteNode();
            break;

        case 3:
            viewList();
            break;

        case 4:
            exit(0);

        default:
            cout<<"Invalid Choice";
        }
    }

    return 0;
}
